package com.kacis.game;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.FullScreenContentCallback;

public class MainActivity extends Activity {
    private WebView webView;
    private RewardedAd rewardedAd;
    private final String REWARDED_ID = "ca-app-pub-3737257512096305/3500641120";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        MobileAds.initialize(this, status -> loadRewarded());

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AdMobBridge(), "AndroidAdMob");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void loadRewarded() {
        AdRequest request = new AdRequest.Builder().build();
        RewardedAd.load(this, REWARDED_ID, request, new RewardedAdLoadCallback() {
            @Override public void onAdLoaded(RewardedAd ad) {
                rewardedAd = ad;
                rewardedAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override public void onAdDismissedFullScreenContent() {
                        rewardedAd = null;
                        loadRewarded();
                    }
                    @Override public void onAdFailedToShowFullScreenContent(AdError adError) {
                        rewardedAd = null;
                        loadRewarded();
                    }
                });
            }
            @Override public void onAdFailedToLoad(AdError error) {
                rewardedAd = null;
            }
        });
    }

    private class AdMobBridge {
        @JavascriptInterface
        public void showRewardedAd() {
            runOnUiThread(() -> {
                if (rewardedAd == null) {
                    Toast.makeText(MainActivity.this, "Reklam henüz hazır değil.", Toast.LENGTH_SHORT).show();
                    loadRewarded();
                    return;
                }
                rewardedAd.show(MainActivity.this, rewardItem -> {
                    webView.evaluateJavascript("window.onRewardedAdCompleted && window.onRewardedAdCompleted();", null);
                });
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
