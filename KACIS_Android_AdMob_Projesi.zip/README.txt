KAÇIŞ - Android + AdMob proje iskeleti

Bu proje, KACIS_PWA.zip içindeki oyunu Android WebView içinde açar.
Ödüllü reklam köprüsü:
Java -> window.AndroidAdMob.showRewardedAd()
Reklam ödülü -> window.onRewardedAdCompleted()

AdMob App ID ve Rewarded Ad Unit ID proje içine yerleştirilmiştir.
SDK: Google Mobile Ads Android SDK 25.5.0.

ÖNEMLİ:
- Bu ZIP kaynak Android projesidir; tek başına Play Store'a yüklenebilir AAB değildir.
- Derleme/signing işlemi Android Studio/Gradle ortamında yapılmalıdır.
- Play Console'a göndermeden önce gerçek cihazda test ve Google'ın reklam/mahremiyet gereklilikleri kontrol edilmelidir.
